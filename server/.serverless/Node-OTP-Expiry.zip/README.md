# NodeJs-Phone-Number-verification
Nodejs-express api to validate the phone numbers
